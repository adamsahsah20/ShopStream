import './App.css'
import { createBrowserRouter, RouterProvider } from 'react-router'
import MainLayout from './Layout/MainLayout'
import Home from './pages/Home/Home'
import Category from './pages/Category/Category'
import Products from './pages/Products/Products'
import Cart from './pages/Cart'
import ThemeProvider from './Context/ThemeProvider'
import ProductDetails from './Components/Cards/Product/ProductDetails'
import Registration from './pages/Auth/Register'
import Login from './pages/Auth/login'
import Register from './pages/Auth/Register'

function App() {
  let router=createBrowserRouter([{
    path:"/",
    element:<MainLayout/>,
    children:[
      {index:true, element:<Home/>},
      {path:"/products",element:<Products/>},
      {path:"/productDetails/:id",element:<ProductDetails/>},
      {path:"/category", element:<Category/>},
      {path:"/cart", element:<Cart/>},
      {path:"/register",element:<Register/>},
      {path:"/login",element:<Login/>}
    ]
  }])

  return (
   <ThemeProvider>
    <RouterProvider router={router} />
   </ThemeProvider>
  )
}

export default App
