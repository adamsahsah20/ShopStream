import React, {  useState } from 'react'
import { registeredUsers } from "./Registerion";


export default function Login() {
  let[checkEmail,setCheckEmail]=useState("")
  let [checkPassword,setCheckPassword]=useState("")
  let [error,setError]=useState()
  function handleSubmit(e){
    e.preventDefaul()
    let found=registeredUsers.find((u)=> u.email == u.checkEmail && u.password ==checkPassword)
    if(found){
      navgate("/")
    }else{
      setError("Incorrect email or password")
    }
  }
  return (
      <div className="d-flex justify-content-center py-5">
      <form
        onSubmit={handleSubmit}
        style={{ width: "440px" }}
        className="border rounded-2 shadow-sm p-4 d-flex flex-column gap-3">
        <h3 className="fw-bold text-center">Welcome back</h3>
        <p className="text-secondary text-center">
          Please enter your details to sign in.
        </p>

        <div className="d-flex gap-3">
          <div className="w-50">
            <label className="fw-bold">Email Address</label>
            <input
              type="email"
              className="form-control"
              placeholder="adam@email.com"
              value={checkEmail}
              onChange={(e) => setCheckEmail(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="fw-bold">Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="••••••••"
            value={checkPassword}
            onChange={(e) => setCheckPassword(e.target.value)}
          />
        </div>

        {error && <p className="text-danger">{error}</p>}

        <label className="d-flex gap-2">
          <input type="checkbox" required /> Stay signed in for 30 days
        </label>

        <Button type="submit" variant="primary" className="fw-bold">
          Sign In →
        </Button>

        

        <p className="text-center">
          Do not have account? <Link to="/register">Register</Link>
        </p>
      </form>
    </div>
  )
}
