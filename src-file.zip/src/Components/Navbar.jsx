import React, { useContext, useState } from 'react'
import { themeContext } from '../Context/themeContext'
import { Link, NavLink, useNavigate } from 'react-router';


export default function Navbar() {
  let {theme,toggleTheme}=useContext(themeContext)
  let [query,setQuery]=useState("")
  let navigate=useNavigate()
  let links=[
    {to:"/" , name:"Home"},
    {to:"/products" , name:"Products"},
    {to:"/category" , name:"Category"},
  ];

  return (
    <header className="position-sticky top-0 start-0 d-flex justify-content-between align-items-center px-4 z-3">
        <h3 className="text-info px-3 py-1 fw-bold text-capitalize">ShopStream</h3>
        <nav className="d-flex justify-content-between align-items-center gap-3">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} className={({isActive}) =>isActive ?"text-info" :"text-decoration-none"}>
                {link.name}
            </NavLink>
          ))}
        </nav>
        <div>
         <input
          className="form-control"
          placeholder="Search Products..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value)
            navigate(`/products?q=${e.target.value}`)
          }}
          />
        </div>
        <div className="d-flex justify-content-between align-items-center gap-3" >
            <Link to="/cart" className="text-info text-decoration-none p-2">Cart</Link>
            <button className="border border-0" onClick={()=> toggleTheme()}>{theme == "light" ? "🌙" : "🔆"}</button>
        </div>
    </header>
  )
}
