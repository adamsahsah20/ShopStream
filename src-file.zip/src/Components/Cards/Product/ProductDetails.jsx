import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap';
import { useParams } from 'react-router'
import { addToCart } from '../../../RTK/slices/cartSlice';
import { useDispatch } from 'react-redux';

export default function ProductDetails() {
    let {id}=useParams();
    let dispatch=useDispatch()
    let [product,setProduct]=useState({})
    useEffect(()=> {
        async function fetchProduct() {
            let res= await axios.get(`https://dummyjson.com/products/${id}`)
            setProduct(res.data)
        }
        fetchProduct()
    },[id])
  return (
    <div>
        {product.discountPercentage > 0 &&(<p className="position-sticky d-flex bg-danger top-0 end-0 text-white fs-6 rounded-1" style={{width:"100px"}}>{product.discountPercentage}%</p>)}
        <img src={product.thumbnail} alt={product.title} style={{width:"300px",marginLeft:"520px"}}/>
        <h2 className="text-dark fw-bold text-center">⭐{product.title}</h2>
        <p className="text-dark fw-bold text-center">{product.rating}</p>
        <p className="text-secondary text-center">{product.description}</p>
        <p className="text-success text-center">${product.price}</p>
    
        <Button variant="outline-primary" style={{marginLeft:"620px"}} onClick={()=> dispatch(addToCart(product))}>Add to Cart</Button>
        
    </div>
  )
}
