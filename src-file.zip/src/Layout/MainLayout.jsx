import React from 'react'
import Navbar from '../Components/Navbar'
import { Outlet } from 'react-router'

export default function MainLayout() {
  return (
    <div>
        <Navbar/>
        <main className="d-flex jusitify-content-center flex-column py-5">
            <Outlet/>
        </main>

        <footer>This is footer</footer>
    </div>
  )
}
